<?php
    $usuario=$_POST['email'];
    $contraseña = $_POST['pasword'];
    session_start();
    $_SESSION['email'] = $usuario;

    $conexion = mysqli_connect('localhost','root','','design_your_home');
    // include('db.php');

    $consulta = "SELECT * FROM usuarios WHERE correo='$usuario' and contraseña='$contraseña'";
    $resultado = mysqli_query($conexion,$consulta);
    $filas=mysqli_num_rows($resultado);

    if($filas){
        header("location:../crud.html");
    }else{
        ?>
        <?php
            include("login.html");
        ?>
        <h2>No esta registrado</h2>
        <?php
    }
    mysqli_free_result($resultado);
    mysqli_close($conexion);
?>
<?php 
    $conexion = mysqli_connect('localhost','root','','design_your_home');
    insertar($conexion);

    function insertar($conexion){
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $pasword = $_POST['pasword'];
        $cliente = "cliente";

        $consulta = "INSERT INTO usuarios(`nombre`,`apellido`, `correo`, `contraseña`,`estado` ) VALUES ('$nombre','$apellido','$email','$pasword','$cliente')";
    mysqli_query($conexion, $consulta);
    mysqli_close($conexion);
    }
    
?>